# COLAV Protobuf

Protobuf Serialiser used for exteral-internal COLAV communication over UDP therefore this repository contains the proto the compiled bin files for this protos for different message types.

